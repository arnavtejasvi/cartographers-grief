package com.arnav.cartographersgrief.block;

import com.arnav.cartographersgrief.registry.ModBlockEntityTypes;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public class GriefSkullBlock extends class_2237 {
    public static final MapCodec<GriefSkullBlock> CODEC = method_54094(GriefSkullBlock::new);

    public GriefSkullBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GriefSkullBlockEntity(pos, state);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.method_8608()) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof GriefSkullBlockEntity skull) {
                long day = skull.getDeathTick() / 24000L + 1;
                player.method_7353(class_2561.method_43470(
                    "§5[Cartographer] §r" + skull.getPlayerName() +
                    " §7died here on §5Day " + day + "§7 — " + skull.getDeathMessage()
                ), false);
            }
        }
        return class_1269.field_5812;
    }
}
