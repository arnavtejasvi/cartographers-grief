package com.arnav.cartographersgrief.block;

import com.arnav.cartographersgrief.registry.ModBlockEntityTypes;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class GriefSkullBlockEntity extends class_2586 {
    private long deathTick = 0L;
    private String deathMessage = "unknown causes";
    private String playerName = "Someone";

    public GriefSkullBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntityTypes.GRIEF_SKULL_ENTITY, pos, state);
    }

    public void setData(long deathTick, String deathMessage, String playerName) {
        this.deathTick = deathTick;
        this.deathMessage = deathMessage;
        this.playerName = playerName;
        method_5431();
    }

    public long getDeathTick()    { return deathTick; }
    public String getDeathMessage() { return deathMessage; }
    public String getPlayerName() { return playerName; }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10544("deathTick", deathTick);
        nbt.method_10582("deathMessage", deathMessage);
        nbt.method_10582("playerName", playerName);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        deathTick = nbt.method_10537("deathTick");
        deathMessage = nbt.method_10558("deathMessage");
        playerName = nbt.method_10558("playerName");
    }
}
