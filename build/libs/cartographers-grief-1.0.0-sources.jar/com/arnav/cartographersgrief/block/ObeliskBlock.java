package com.arnav.cartographersgrief.block;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class ObeliskBlock extends class_2248 {

    public ObeliskBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.method_8608()) {
            player.method_7353(class_2561.method_43470(
                "§5[Cartographer] §7This place holds an old grief. The memory has crystallized."
            ), false);
        }
        return class_1269.field_5812;
    }
}
