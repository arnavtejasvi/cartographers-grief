package com.arnav.cartographersgrief.event;

import com.arnav.cartographersgrief.tracker.ExploredChunkTracker;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class ChunkLoadHandler {

    public static void register() {
        ClientChunkEvents.CHUNK_LOAD.register(ChunkLoadHandler::onChunkLoad);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String worldId = resolveWorldId(client);
            ExploredChunkTracker.load(worldId);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ExploredChunkTracker.save();
        });
    }

    private static void onChunkLoad(class_638 world, class_2818 chunk) {
        ExploredChunkTracker.onChunkLoaded(chunk.method_12004().field_9181, chunk.method_12004().field_9180);
    }

    private static String resolveWorldId(class_310 client) {
        if (client.method_1576() != null) {
            return "singleplayer_" + client.method_1576().method_27728().method_150();
        }
        if (client.method_1558() != null) {
            return "server_" + client.method_1558().field_3761;
        }
        return "unknown";
    }
}
