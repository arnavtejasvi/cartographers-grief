package com.arnav.cartographersgrief.event;

import com.arnav.cartographersgrief.block.GriefSkullBlockEntity;
import com.arnav.cartographersgrief.registry.ModBlocks;
import com.arnav.cartographersgrief.world.DeathRecord;
import com.arnav.cartographersgrief.world.DeathTracker;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class DeathEventHandler {

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DEATH.register(DeathEventHandler::onDeath);
    }

    private static boolean onDeath(class_1309 entity, class_1282 source, float amount) {
        if (!(entity instanceof class_3222 player)) return true;

        class_3218 world = (class_3218) player.method_37908();
        class_2338 pos = findSolidSurface(world, player.method_24515());

        world.method_8501(pos, ModBlocks.GRIEF_SKULL.method_9564());

        if (world.method_8321(pos) instanceof GriefSkullBlockEntity skull) {
            String message = source.method_5506(player).getString();
            String name = player.method_5820();
            long tick = world.method_8510();
            skull.setData(tick, message, name);
            DeathTracker.get(world).add(new DeathRecord(pos, tick, message, name));
        }

        return true;
    }

    private static class_2338 findSolidSurface(class_3218 world, class_2338 origin) {
        class_2338 pos = origin;
        for (int i = 0; i < 8; i++) {
            if (!world.method_8320(pos).method_26215()) {
                return pos.method_10084();
            }
            pos = pos.method_10074();
        }
        return origin;
    }
}
