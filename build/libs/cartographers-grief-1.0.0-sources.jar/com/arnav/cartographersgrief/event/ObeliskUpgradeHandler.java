package com.arnav.cartographersgrief.event;

import com.arnav.cartographersgrief.registry.ModBlocks;
import com.arnav.cartographersgrief.world.DeathRecord;
import com.arnav.cartographersgrief.world.DeathTracker;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.List;

public final class ObeliskUpgradeHandler {

    private static final long UPGRADE_TICKS = 168_000L;
    private static final int CHECK_INTERVAL = 200;

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(ObeliskUpgradeHandler::onWorldTick);
    }

    private static void onWorldTick(class_3218 world) {
        if (world.method_8510() % CHECK_INTERVAL != 0) return;

        long now = world.method_8510();
        DeathTracker tracker = DeathTracker.get(world);

        List<class_2338> toUpgrade = new ArrayList<>();
        for (DeathRecord record : tracker.getAll()) {
            if (now - record.tick() < UPGRADE_TICKS) continue;
            if (!world.method_8320(record.pos()).method_27852(ModBlocks.GRIEF_SKULL)) continue;
            toUpgrade.add(record.pos());
        }
        for (class_2338 pos : toUpgrade) {
            world.method_8501(pos, ModBlocks.OBELISK.method_9564());
            tracker.remove(pos);
        }
    }
}
