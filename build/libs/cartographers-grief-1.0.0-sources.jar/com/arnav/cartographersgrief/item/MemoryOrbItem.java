package com.arnav.cartographersgrief.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class MemoryOrbItem extends class_1792 {

    private static final String TAG_X   = "MemX";
    private static final String TAG_Y   = "MemY";
    private static final String TAG_Z   = "MemZ";
    private static final String TAG_DIM = "MemDim";

    public MemoryOrbItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (world.method_8608()) return class_1271.method_22427(stack);

        class_9279 nbtComponent = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        class_2487 nbt = nbtComponent.method_57461();
        String currentDim = world.method_27983().method_29177().toString();

        if (!nbt.method_10545(TAG_X)) {
            class_2338 pos = player.method_24515();
            nbt.method_10569(TAG_X, pos.method_10263());
            nbt.method_10569(TAG_Y, pos.method_10264());
            nbt.method_10569(TAG_Z, pos.method_10260());
            nbt.method_10582(TAG_DIM, currentDim);
            stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
            player.method_7353(class_2561.method_43470(
                "§5[Cartographer] §7Memory captured at §5" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + "§7."
            ), false);
        } else {
            int mx = nbt.method_10550(TAG_X);
            int my = nbt.method_10550(TAG_Y);
            int mz = nbt.method_10550(TAG_Z);
            String dim = nbt.method_10558(TAG_DIM);

            class_2338 here = player.method_24515();
            double dist = Math.sqrt(
                Math.pow(here.method_10263() - mx, 2) +
                Math.pow(here.method_10264() - my, 2) +
                Math.pow(here.method_10260() - mz, 2)
            );

            String dimNote = dim.equals(currentDim) ? "" : " §c(different dimension)";
            player.method_7353(class_2561.method_43470(
                "§5[Cartographer] §7Memory: §5" + mx + ", " + my + ", " + mz +
                "§7 — §5" + (int) dist + " §7blocks away" + dimNote
            ), false);
        }

        return class_1271.method_22427(stack);
    }
}
