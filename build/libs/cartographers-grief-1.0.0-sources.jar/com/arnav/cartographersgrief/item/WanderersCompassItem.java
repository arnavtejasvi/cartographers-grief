package com.arnav.cartographersgrief.item;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7924;

public class WanderersCompassItem extends class_1792 {

    private static final List<String> STRUCTURE_IDS = List.of(
        "minecraft:village_plains",
        "minecraft:village_savanna",
        "minecraft:village_taiga",
        "minecraft:village_desert",
        "minecraft:village_snowy",
        "minecraft:ruined_portal",
        "minecraft:pillager_outpost",
        "minecraft:desert_pyramid",
        "minecraft:jungle_pyramid",
        "minecraft:swamp_hut",
        "minecraft:igloo",
        "minecraft:shipwreck",
        "minecraft:buried_treasure"
    );

    public WanderersCompassItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (world.method_8608()) return class_1271.method_22427(stack);

        class_3218 serverWorld = (class_3218) world;
        class_2338 origin = player.method_24515();

        Optional<class_2338> found = locateNearestStructure(serverWorld, origin);

        if (found.isEmpty()) {
            player.method_7353(class_2561.method_43470(
                "§5[Cartographer] §7The compass spins wildly. No uncharted territory found nearby."
            ), false);
        } else {
            class_2338 target = found.get();
            int dx = target.method_10263() - origin.method_10263();
            int dz = target.method_10260() - origin.method_10260();
            double dist = Math.sqrt((double) dx * dx + (double) dz * dz);
            String arrow = directionArrow(dx, dz);
            player.method_7353(class_2561.method_43470(
                "§5[Cartographer] §7Uncharted territory: §5" + target.method_10263() + ", " + target.method_10260() +
                "§7 — §5" + (int) dist + " §7blocks " + arrow
            ), false);
        }

        return class_1271.method_22427(stack);
    }

    private Optional<class_2338> locateNearestStructure(class_3218 world, class_2338 origin) {
        var structureRegistry = world.method_30349().method_30530(class_7924.field_41246);

        for (String id : STRUCTURE_IDS) {
            class_5321<class_3195> key = class_5321.method_29179(class_7924.field_41246, class_2960.method_60654(id));
            Optional<class_6880.class_6883<class_3195>> entryOpt = structureRegistry.method_40264(key);
            if (entryOpt.isEmpty()) continue;

            class_6885<class_3195> list = class_6885.method_40246(entryOpt.get());
            var result = world.method_14178().method_12129()
                .method_12103(world, list, origin, 100, false);
            if (result != null) return Optional.of(result.getFirst());
        }
        return Optional.empty();
    }

    private String directionArrow(int dx, int dz) {
        double angle = Math.toDegrees(Math.atan2(dz, dx));
        if (angle < 0) angle += 360;

        if (angle < 22.5 || angle >= 337.5) return "→ E";
        if (angle < 67.5)  return "↘ SE";
        if (angle < 112.5) return "↓ S";
        if (angle < 157.5) return "↙ SW";
        if (angle < 202.5) return "← W";
        if (angle < 247.5) return "↖ NW";
        if (angle < 292.5) return "↑ N";
        return "↗ NE";
    }
}
