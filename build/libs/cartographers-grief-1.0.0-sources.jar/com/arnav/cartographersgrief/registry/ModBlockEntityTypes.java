package com.arnav.cartographersgrief.registry;

import com.arnav.cartographersgrief.block.GriefSkullBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModBlockEntityTypes {
    public static final class_2591<GriefSkullBlockEntity> GRIEF_SKULL_ENTITY =
        class_2378.method_10230(class_7923.field_41181,
            class_2960.method_60655("cartographersgrief", "grief_skull_entity"),
            class_2591.class_2592.method_20528(GriefSkullBlockEntity::new, ModBlocks.GRIEF_SKULL).build());

    public static void register() {}
}
