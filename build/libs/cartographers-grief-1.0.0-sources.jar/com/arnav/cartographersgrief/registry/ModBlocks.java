package com.arnav.cartographersgrief.registry;

import com.arnav.cartographersgrief.block.GriefSkullBlock;
import com.arnav.cartographersgrief.block.ObeliskBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {
    public static final class_2248 GRIEF_SKULL = register("grief_skull",
        new GriefSkullBlock(class_4970.class_2251.method_9637()
            .method_9629(1.5f, 6.0f)
            .method_9626(class_2498.field_11544)
            .method_9631(state -> 8)
            .method_31710(class_3620.field_16014)
            .method_51368(class_2766.field_12653)
            .method_29292()));

    public static final class_2248 OBELISK = register("obelisk",
        new ObeliskBlock(class_4970.class_2251.method_9637()
            .method_9629(2.0f, 8.0f)
            .method_9626(class_2498.field_11544)
            .method_9631(state -> 12)
            .method_31710(class_3620.field_16029)
            .method_51368(class_2766.field_12653)
            .method_29292()));

    private static class_2248 register(String id, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655("cartographersgrief", id), block);
    }

    public static void register() {}
}
