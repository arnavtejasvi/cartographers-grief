package com.arnav.cartographersgrief.registry;

import com.arnav.cartographersgrief.item.MemoryOrbItem;
import com.arnav.cartographersgrief.item.WanderersCompassItem;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {
    public static final class_1792 MEMORY_SHARD = register("memory_shard",
        new class_1792(new class_1792.class_1793().method_7894(class_1814.field_8907)));

    public static final class_1792 MEMORY_ORB = register("memory_orb",
        new MemoryOrbItem(new class_1792.class_1793().method_7889(1)));

    public static final class_1792 WANDERERS_COMPASS = register("wanderers_compass",
        new WanderersCompassItem(new class_1792.class_1793().method_7889(1)));

    // Block items
    public static final class_1792 GRIEF_SKULL_ITEM = register("grief_skull",
        new class_1747(ModBlocks.GRIEF_SKULL, new class_1792.class_1793()));

    public static final class_1792 OBELISK_ITEM = register("obelisk",
        new class_1747(ModBlocks.OBELISK, new class_1792.class_1793()));

    private static class_1792 register(String id, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("cartographersgrief", id), item);
    }

    public static void register() {}
}
