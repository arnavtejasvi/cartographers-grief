package com.arnav.cartographersgrief.world;

import net.minecraft.class_2338;

public record DeathRecord(class_2338 pos, long tick, String message, String player) {}
