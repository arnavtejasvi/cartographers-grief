package com.arnav.cartographersgrief.world;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class DeathTracker extends class_18 {
    private static final String KEY = "cartographers_grief_deaths";
    private static final class_8645<DeathTracker> TYPE = new class_8645<>(
        DeathTracker::new,
        (nbt, registries) -> fromNbt(nbt),
        null
    );

    private final List<DeathRecord> records = new ArrayList<>();

    public static DeathTracker get(class_3218 world) {
        class_26 mgr = world.method_17983();
        return mgr.method_17924(TYPE, KEY);
    }

    public void add(DeathRecord record) {
        records.add(record);
        method_80();
    }

    public void remove(class_2338 pos) {
        records.removeIf(r -> r.pos().equals(pos));
        method_80();
    }

    public List<DeathRecord> getAll() {
        return Collections.unmodifiableList(records);
    }

    @Override
    public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registries) {
        class_2499 list = new class_2499();
        for (DeathRecord r : records) {
            class_2487 entry = new class_2487();
            entry.method_10544("pos", r.pos().method_10063());
            entry.method_10544("tick", r.tick());
            entry.method_10582("message", r.message());
            entry.method_10582("player", r.player());
            list.add(entry);
        }
        nbt.method_10566("records", list);
        return nbt;
    }

    private static DeathTracker fromNbt(class_2487 nbt) {
        DeathTracker tracker = new DeathTracker();
        class_2499 list = nbt.method_10554("records", class_2520.field_33260);
        for (int i = 0; i < list.size(); i++) {
            class_2487 entry = list.method_10602(i);
            tracker.records.add(new DeathRecord(
                class_2338.method_10092(entry.method_10537("pos")),
                entry.method_10537("tick"),
                entry.method_10558("message"),
                entry.method_10558("player")
            ));
        }
        return tracker;
    }
}
